SLogBog / phpBB3 Custom FOBB & Key-Fob Smilie Pack
==================================================
1. Upload icon_fobb_24.png, icon_fobb_32.png, icon_fob_32.png, and fobb_smilies.pak into /images/smilies/.
2. In phpBB ACP -> Posting -> Messages -> Smilies -> "Install smilies package".
3. Select fobb_smilies.pak -> Choose "Keep all" -> Submit.
4. Codes:
   :fobb: -> 24px inline FOBB (Flying Object Built to Bounce)
   :FOBB: -> 32px FOBB
   :fob:  -> 32px MSD RP11 315MHz Wireless Key Fob
